package com.enterprise.java;

public class Reservation {
	private String name;
	private String airline;
	private String date;
	private String time;
	private String flight;
	private String seat;
	
	


	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getFlight() {
		return flight;
	}
	public void setFlight(String flight) {
		this.flight = flight;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public Reservation(String name, String airline, String date, String time, String flight, String seat) {
		super();
		this.name = name;
		this.airline = airline;
		this.date = date;
		this.time = time;
		this.flight = flight;
		this.seat = seat;
	}
	public Reservation() {
		super();
	}
	


}


