package com.enterprise.java;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
	public class AirReservationController {

	    @RequestMapping("/")
	    public String Reservation(Model model) {
	        model.addAttribute("reservation", new Reservation("1","2","1","2","1","2"));
	        return "index";
	    }

	    @RequestMapping("/submitReservation")
	    public String submitReservation(@ModelAttribute Reservation reservation, Model model) {
	        model.addAttribute("reservation", reservation);
	        return "displayAirReservation";
	    }
	}



