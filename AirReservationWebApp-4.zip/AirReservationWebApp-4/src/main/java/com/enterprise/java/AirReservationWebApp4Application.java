package com.enterprise.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirReservationWebApp4Application {

	public static void main(String[] args) {
		SpringApplication.run(AirReservationWebApp4Application.class, args);
	}

}
